cd tests/arith_tests
bash test.sh