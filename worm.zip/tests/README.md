# Test scripts for CSE201A

Please merge your homework with the repepctive test script repository. You should include a *Makefile* 
such that running make in the root directory of your submission produces a file in the root directory.
The file, when executed, should read the strings via stdin and output the required content via stdout.

These test scripts are prepared based on [Sohum Banerjea's work](https://github.com/SohumB/cse210A-asgtest/tree/master).
