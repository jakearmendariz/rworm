# Mistakes

- Cloning, I am cloning the code too much, causing a really expensive project, I need to add lifetimes to my project
- Lacking internal mutability, wanting to add a type inference algorithm, but I can't edit the syntax tree